<?php
    echo 'Avvio programma: ' . $_GET['x'];
    $nome = $_GET['x'];
    echo exec('python stream.py ./upload/' . $nome . " /dev/ttyS1 > /dev/null &");
    echo "<meta http-equiv=\"Refresh\" content=\"0;url=$_SERVER[HTTP_REFERER]\">";
?>
