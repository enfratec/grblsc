<html>
<head>
	<title>GRBL Manager</title>
</head>
<body>
<h2 style="text-align: center;"><span style="font-family:arial,helvetica,sans-serif;">File caricati:</span></h2>
<?php
    if ($handle = opendir('upload/')) {
    	while (false !== ($entry = readdir($handle))) {
    		if ($entry != "." && $entry != "..") {
    			echo '<a href="python.php?x='.$entry.'">'.$entry.'</a> ';
    			echo '<a href="edit.php?x='.$entry.'">Modifica</a> ';
    			echo '<a href="del.php?x='.$entry.'">Cancella</a><br>';
    		}
    	}
    	closedir($handle);
    }
?>
</html>
