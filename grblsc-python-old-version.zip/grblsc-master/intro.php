<html>
<head>
	<title>GRBL Manager</title>
</head>
<body>
<h1 style="text-align: center;"><span style="font-family:arial,helvetica,sans-serif;">GRBL Manager</span></h1>
<div align="center" text-align="left">
<p><form method="post" action="upload.php" enctype="multipart/form-data">
    <input type="file" name="miofile">
    <input type="submit" value="Upload">
</form></p>
</div>
<br>
<a href="log.html" target="log">Aggiorna stato lavorazioni</a>
<br>
<?php include'read.php'; ?>
<br>
<a href="new.php">Nuova lavorazione</a>
<br>
</html>

